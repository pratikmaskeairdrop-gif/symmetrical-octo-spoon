import { config } from 'dotenv';
config();

import '@/ai/flows/playbook-generation.ts';
import '@/ai/flows/ai-insights-trades.ts';