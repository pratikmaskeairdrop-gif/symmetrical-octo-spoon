'use server';

/**
 * @fileOverview Generates trade playbooks for specific strategies or instruments with AI explanations.
 *
 * - generatePlaybook - A function that generates the playbook.
 * - GeneratePlaybookInput - The input type for the generatePlaybook function.
 * - GeneratePlaybookOutput - The return type for the generatePlaybook function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GeneratePlaybookInputSchema = z.object({
  strategy: z
    .string()
    .describe('The trading strategy or instrument to generate a playbook for.'),
  pastData: z
    .string()
    .describe('Past trading data related to the strategy or instrument.'),
});
export type GeneratePlaybookInput = z.infer<typeof GeneratePlaybookInputSchema>;

const GeneratePlaybookOutputSchema = z.object({
  playbook: z.string().describe('The generated trade playbook.'),
  explanation: z.string().describe('AI-provided explanation of the strategy.'),
});
export type GeneratePlaybookOutput = z.infer<typeof GeneratePlaybookOutputSchema>;

export async function generatePlaybook(input: GeneratePlaybookInput): Promise<GeneratePlaybookOutput> {
  return generatePlaybookFlow(input);
}

const prompt = ai.definePrompt({
  name: 'generatePlaybookPrompt',
  input: {schema: GeneratePlaybookInputSchema},
  output: {schema: GeneratePlaybookOutputSchema},
  prompt: `You are an expert trading strategist. Generate a trade playbook for the following strategy or instrument:

Strategy/Instrument: {{{strategy}}}

Past Data: {{{pastData}}}

Provide a clear and actionable playbook, along with an AI-powered explanation of the strategy and its potential application, include entry and exit strategy.`,
});

const generatePlaybookFlow = ai.defineFlow(
  {
    name: 'generatePlaybookFlow',
    inputSchema: GeneratePlaybookInputSchema,
    outputSchema: GeneratePlaybookOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
