'use server';

/**
 * @fileOverview An AI-powered insights tool for analyzing trading data.
 *
 * - getAiTradingInsights - A function that generates personalized insights for improved decision-making.
 * - AiTradingInsightsInput - The input type for the getAiTradingInsights function.
 * - AiTradingInsightsOutput - The return type for the getAiTradingInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiTradingInsightsInputSchema = z.object({
  tradeData: z
    .string()
    .describe(
      'A string containing trade data in a parsable format (e.g., JSON or CSV).'
    ),
  userProfile: z
    .string()
    .optional()
    .describe(
      'Optional user profile information including risk tolerance, trading goals, and experience level.'
    ),
});
export type AiTradingInsightsInput = z.infer<typeof AiTradingInsightsInputSchema>;

const AiTradingInsightsOutputSchema = z.object({
  insights: z
    .string()
    .describe(
      'AI-generated insights and recommendations based on the trading data and user profile.'
    ),
});
export type AiTradingInsightsOutput = z.infer<typeof AiTradingInsightsOutputSchema>;

export async function getAiTradingInsights(input: AiTradingInsightsInput): Promise<AiTradingInsightsOutput> {
  return aiTradingInsightsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiTradingInsightsPrompt',
  input: {schema: AiTradingInsightsInputSchema},
  output: {schema: AiTradingInsightsOutputSchema},
  prompt: `You are an AI-powered trading insights generator. Analyze the provided trading data and user profile (if available) to provide personalized insights and recommendations for improved decision-making.

Trading Data:
{{tradeData}}

User Profile (Optional):
{{#if userProfile}}{{userProfile}}{{else}}No user profile provided.{{/if}}

Based on this information, provide actionable insights covering areas such as:
- Strengths and weaknesses in trading strategies
- Risk management effectiveness
- Optimal times or instruments for trading
- Potential biases in decision-making

Format your response in a clear, concise, and easily understandable manner. Focus on providing practical recommendations that the user can implement to enhance their trading performance.
`,
});

const aiTradingInsightsFlow = ai.defineFlow(
  {
    name: 'aiTradingInsightsFlow',
    inputSchema: AiTradingInsightsInputSchema,
    outputSchema: AiTradingInsightsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
