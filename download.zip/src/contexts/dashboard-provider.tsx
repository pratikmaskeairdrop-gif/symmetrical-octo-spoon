
'use client';

import React, { createContext, useContext, useState, useEffect, type ReactNode } from 'react';

type ComponentVisibility = {
  pnlStats: boolean;
  tradeWinRate: boolean;
  profitFactor: boolean;
  calendar: boolean;
  winRateStats: boolean;
  recentTrades: boolean;
  dailyPnl: boolean;
  cumulativePnl: boolean;
  winLoss: boolean;
  avgWinLoss: boolean;
  dayStreak: boolean;
  tradeStreak: boolean;
  dayWinRate: boolean;
  accountBalance: boolean;
  visionScore: boolean;
};

type DashboardContextType = {
  visibleComponents: ComponentVisibility;
  toggleComponentVisibility: (component: keyof ComponentVisibility) => void;
};

const defaultVisibility: ComponentVisibility = {
  pnlStats: true,
  tradeWinRate: true,
  profitFactor: true,
  calendar: true,
  winRateStats: true,
  recentTrades: true,
  dailyPnl: true,
  cumulativePnl: true,
  winLoss: true,
  avgWinLoss: true,
  dayStreak: true,
  tradeStreak: true,
  dayWinRate: true,
  accountBalance: true,
  visionScore: true,
};

const DashboardContext = createContext<DashboardContextType | undefined>(undefined);

export function DashboardProvider({ children }: { children: ReactNode }) {
  const [visibleComponents, setVisibleComponents] = useState<ComponentVisibility>(defaultVisibility);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    try {
      const savedState = localStorage.getItem('dashboardVisibility');
      if (savedState) {
        const parsedState = JSON.parse(savedState);
        setVisibleComponents({ ...defaultVisibility, ...parsedState });
      }
    } catch (error) {
      console.error("Failed to parse dashboard visibility from localStorage", error);
    }
    setIsLoaded(true);
  }, []);

  useEffect(() => {
    if (isLoaded) {
        try {
            localStorage.setItem('dashboardVisibility', JSON.stringify(visibleComponents));
        } catch (error) {
            console.error("Failed to save dashboard visibility to localStorage", error);
        }
    }
  }, [visibleComponents, isLoaded]);

  const toggleComponentVisibility = (component: keyof ComponentVisibility) => {
    setVisibleComponents((prevState) => ({
      ...prevState,
      [component]: !prevState[component],
    }));
  };
  
  if (!isLoaded) {
    return null; 
  }

  return (
    <DashboardContext.Provider value={{ visibleComponents, toggleComponentVisibility }}>
      {children}
    </DashboardContext.Provider>
  );
}

export function useDashboard() {
  const context = useContext(DashboardContext);
  if (context === undefined) {
    throw new Error('useDashboard must be used within a DashboardProvider');
  }
  return context;
}
