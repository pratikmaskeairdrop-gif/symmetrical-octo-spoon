'use client';

import type { Trade } from '@/lib/types';
import { initialTrades as rawInitialTrades } from '@/lib/data';
import React, { createContext, useContext, useReducer, type ReactNode, useEffect, useState } from 'react';

// In a real app, this would be fetched from a user settings collection in a database.
const DEFAULT_RISK_PER_TRADE = 100; // Let's assume a default risk of $100

type State = {
  trades: Trade[];
  riskPerTrade: number;
};

type Action = 
  | { type: 'SET_TRADES'; payload: Trade[] }
  | { type: 'ADD_TRADE'; payload: Trade }
  | { type: 'SET_RISK'; payload: number };


type TradeContextType = {
  trades: Trade[];
  riskPerTrade: number;
  addTrade: (trade: Omit<Trade, 'id' | 'pnl' | 'rValue'>) => void;
  setRiskPerTrade: (risk: number) => void;
};

const TradeContext = createContext<TradeContextType | undefined>(undefined);

function tradeReducer(state: State, action: Action): State {
  switch (action.type) {
    case 'SET_TRADES':
      return { ...state, trades: action.payload };
    case 'ADD_TRADE': {
      return {
        ...state,
        trades: [action.payload, ...state.trades],
      };
    }
    case 'SET_RISK': {
        const newTrades = state.trades.map(trade => ({
            ...trade,
            rValue: state.riskPerTrade > 0 ? trade.pnl / action.payload : 0,
        }));
        return {
            ...state,
            riskPerTrade: action.payload,
            trades: newTrades,
        };
    }
    default:
      return state;
  }
}

const calculateTradeMetrics = (trade: Omit<Trade, 'id'|'pnl'|'rValue'>, riskPerTrade: number) => {
    const { entryPrice, exitPrice, size, direction } = trade;
    const pnl = (direction === 'Long' ? exitPrice - entryPrice : entryPrice - exitPrice) * size;
    const rValue = riskPerTrade > 0 ? pnl / riskPerTrade : 0;
    return { pnl, rValue };
}

export function TradeProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(tradeReducer, { trades: [], riskPerTrade: DEFAULT_RISK_PER_TRADE });
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // On initial load, process the raw trade data to calculate PnL and R-values
    if (!isInitialized) {
        const processedTrades = rawInitialTrades.map((rawTrade, index) => {
            const { pnl, rValue } = calculateTradeMetrics(rawTrade, DEFAULT_RISK_PER_TRADE);
            return {
                ...rawTrade,
                id: `TRD${(rawInitialTrades.length - index).toString().padStart(3, '0')}`,
                pnl,
                rValue,
            };
        }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        dispatch({ type: 'SET_TRADES', payload: processedTrades });
        setIsInitialized(true);
    }
  }, [isInitialized]);

  const addTrade = (trade: Omit<Trade, 'id' | 'pnl' | 'rValue'>) => {
    const { pnl, rValue } = calculateTradeMetrics(trade, state.riskPerTrade);
    const newTrade: Trade = {
        ...trade,
        id: `TRD${(state.trades.length + 1).toString().padStart(3, '0')}`,
        pnl,
        rValue
    };
    dispatch({ type: 'ADD_TRADE', payload: newTrade });
  };

  const setRiskPerTrade = (risk: number) => {
    dispatch({ type: 'SET_RISK', payload: risk });
  };

  return (
    <TradeContext.Provider value={{ trades: state.trades, riskPerTrade: state.riskPerTrade, addTrade, setRiskPerTrade }}>
      {children}
    </TradeContext.Provider>
  );
}

export function useTrades() {
  const context = useContext(TradeContext);
  if (context === undefined) {
    throw new Error('useTrades must be used within a TradeProvider');
  }
  return context;
}
