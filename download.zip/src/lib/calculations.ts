import type { Trade } from '@/lib/types';
import { format, startOfDay } from 'date-fns';


export function calculateNetPnL(trades: Trade[]): number {
  return trades.reduce((acc, trade) => acc + trade.pnl, 0);
}

export function calculateWinRate(trades: Trade[]): number {
  if (trades.length === 0) return 0;
  const wins = trades.filter((trade) => trade.pnl > 0).length;
  return (wins / trades.length) * 100;
}

export function calculateDayWinRate(trades: Trade[]): number {
  if (trades.length === 0) return 0;
  
  const tradesByDay: Record<string, number> = {};
  trades.forEach(trade => {
    const day = new Date(trade.date).toISOString().split('T')[0];
    tradesByDay[day] = (tradesByDay[day] || 0) + trade.pnl;
  });

  const days = Object.values(tradesByDay);
  if (days.length === 0) return 0;

  const winningDays = days.filter(pnl => pnl > 0).length;
  return (winningDays / days.length) * 100;
}

export function getDayWinLossCount(trades: Trade[]): { wins: number; losses: number } {
    if (trades.length === 0) return { wins: 0, losses: 0 };
    
    const tradesByDay: Record<string, number> = {};
    trades.forEach(trade => {
        const day = new Date(trade.date).toISOString().split('T')[0];
        tradesByDay[day] = (tradesByDay[day] || 0) + trade.pnl;
    });

    const days = Object.values(tradesByDay);
    if (days.length === 0) return { wins: 0, losses: 0 };

    const wins = days.filter(pnl => pnl > 0).length;
    const losses = days.filter(pnl => pnl <= 0).length;
    return { wins, losses };
}

export function calculateProfitFactor(trades: Trade[]): number {
  const grossProfit = trades
    .filter((trade) => trade.pnl > 0)
    .reduce((acc, trade) => acc + trade.pnl, 0);
  const grossLoss = Math.abs(
    trades
      .filter((trade) => trade.pnl < 0)
      .reduce((acc, trade) => acc + trade.pnl, 0)
  );
  if (grossLoss === 0) return Infinity;
  return grossProfit / grossLoss;
}

export function calculateAverageWin(trades: Trade[]): number {
  const winningTrades = trades.filter((trade) => trade.pnl > 0);
  if (winningTrades.length === 0) return 0;
  const totalWin = winningTrades.reduce((acc, trade) => acc + trade.pnl, 0);
  return totalWin / winningTrades.length;
}

export function calculateAverageLoss(trades: Trade[]): number {
  const losingTrades = trades.filter((trade) => trade.pnl < 0);
  if (losingTrades.length === 0) return 0;
  const totalLoss = losingTrades.reduce((acc, trade) => acc + trade.pnl, 0);
  return totalLoss / losingTrades.length;
}

export function calculateCumulativePnL(
  trades: Trade[],
  initialBalance: number = 0
): { date: string; pnl: number }[] {
  let cumulativePnL = initialBalance;
  const sortedTrades = [...trades].sort(
    (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
  );
  
  const dailyPnl: { [key: string]: number } = {};
  sortedTrades.forEach(trade => {
    const day = format(startOfDay(new Date(trade.date)), 'yyyy-MM-dd');
    dailyPnl[day] = (dailyPnl[day] || 0) + trade.pnl;
  });

  const uniqueSortedDays = Object.keys(dailyPnl).sort((a,b) => new Date(a).getTime() - new Date(b).getTime());

  const chartData = uniqueSortedDays.map((day) => {
    cumulativePnL += dailyPnl[day];
    return {
      date: day,
      pnl: cumulativePnL,
    };
  });

  if (chartData.length > 0 && chartData[0].pnl !== initialBalance) {
      chartData.unshift({ date: sortedTrades[0].date, pnl: initialBalance })
  } else if (chartData.length === 0) {
      chartData.push({ date: new Date().toISOString(), pnl: initialBalance })
  }

  return chartData;
}


export function getWinLossData(trades: Trade[]): { name: string, value: number, fill: string }[] {
    const wins = trades.filter(t => t.pnl > 0).length;
    const losses = trades.filter(t => t.pnl <= 0).length;
    return [
        { name: 'Wins', value: wins, fill: 'hsl(var(--chart-2))' },
        { name: 'Losses', value: losses, fill: 'hsl(var(--destructive))' },
    ];
}

export function getWinLossCount(trades: Trade[]): { wins: number, losses: number } {
    const wins = trades.filter(t => t.pnl > 0).length;
    const losses = trades.filter(t => t.pnl <= 0).length;
    return { wins, losses };
}

export type Streak = {
  count: number;
  type: 'W' | 'L';
};

export function calculateDayStreak(trades: Trade[]): Streak {
  if (trades.length === 0) return { count: 0, type: 'W' };

  const tradesByDay: Record<string, number> = {};
  trades.forEach(trade => {
    const day = new Date(trade.date).toISOString().split('T')[0];
    tradesByDay[day] = (tradesByDay[day] || 0) + trade.pnl;
  });

  const sortedDays = Object.keys(tradesByDay).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  
  if (sortedDays.length === 0) return { count: 0, type: 'W' };
  
  const lastDayResult = tradesByDay[sortedDays[0]] > 0 ? 'W' : 'L';
  let streakCount = 0;

  for (const day of sortedDays) {
    const currentDayResult = tradesByDay[day] > 0 ? 'W' : 'L';
    if (currentDayResult === lastDayResult) {
      streakCount++;
    } else {
      break;
    }
  }

  return { count: streakCount, type: lastDayResult };
}

export type TradeStreakInfo = {
    wins: number;
    losses: number;
    currentStreak: Streak;
}

export function calculateTradeStreak(trades: Trade[]): TradeStreakInfo {
    const wins = trades.filter(t => t.pnl > 0).length;
    const losses = trades.filter(t => t.pnl <= 0).length;
    
    if (trades.length === 0) {
        return { wins, losses, currentStreak: { count: 0, type: 'W' } };
    }

    const sortedTrades = [...trades].sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

    const lastTradeResult = sortedTrades[sortedTrades.length - 1].pnl > 0 ? 'W' : 'L';
    let streakCount = 0;

    for (let i = sortedTrades.length - 1; i >= 0; i--) {
        const currentTradeResult = sortedTrades[i].pnl > 0 ? 'W' : 'L';
        if (currentTradeResult === lastTradeResult) {
            streakCount++;
        } else {
            break;
        }
    }
    
    return { wins, losses, currentStreak: { count: streakCount, type: lastTradeResult } };
}
