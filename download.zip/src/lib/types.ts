export type Trade = {
  id: string;
  date: string;
  instrument: string;
  strategy: string;
  direction: 'Long' | 'Short';
  entryPrice: number;
  exitPrice: number;
  size: number;
  pnl: number;
  notes?: string;
  rValue?: number;
};
