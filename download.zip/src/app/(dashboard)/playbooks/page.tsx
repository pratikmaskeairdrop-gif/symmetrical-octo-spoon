import { Header } from '@/components/app/header';
import { PlaybookForm } from '@/components/app/playbooks/playbook-form';

export default function PlaybooksPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header title="AI Playbooks" />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <PlaybookForm />
      </main>
    </div>
  );
}
