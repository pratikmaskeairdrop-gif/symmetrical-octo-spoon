
'use client';

import React from 'react';
import { Header } from '@/components/app/header';
import { useDashboard, DashboardProvider } from '@/contexts/dashboard-provider';
import { TradeWinRateCard } from '@/components/app/dashboard/stats-cards';
import { WinRateStats } from '@/components/app/dashboard/win-rate-stats';
import { RecentTrades } from '@/components/app/dashboard/recent-trades';
import { DailyPnlChart } from '@/components/app/dashboard/daily-pnl-chart';
import { WinLossChart } from '@/components/app/dashboard/win-loss-chart';
import { ProfitFactorChart } from '@/components/app/dashboard/profit-factor-chart';
import { AverageWinLossCard } from '@/components/app/dashboard/average-win-loss-card';
import { StreakCard } from '@/components/app/dashboard/streak-card';
import { DayWinRateCard } from '@/components/app/dashboard/day-win-rate-card';
import { AccountBalanceCard } from '@/components/app/dashboard/account-balance-card';
import { PnlStats } from '@/components/app/dashboard/pnl-stats';
import { cn } from '@/lib/utils';
import { TradeCalendar } from '@/components/app/calendar/trade-calendar';
import { AccountBalanceChart } from '@/components/app/dashboard/account-balance-chart';
import { VisionScore } from '@/components/app/dashboard/vision-score';


function DashboardContent() {
  const { visibleComponents } = useDashboard();

  const statCardComponents = [
    { name: 'pnlStats', component: <PnlStats /> },
    { name: 'tradeWinRate', component: <TradeWinRateCard /> },
    { name: 'dayWinRate', component: <DayWinRateCard /> },
    { name: 'profitFactor', component: <ProfitFactorChart /> },
    { name: 'avgWinLoss', component: <AverageWinLossCard /> },
    { name: 'accountBalance', component: <AccountBalanceCard /> },
    { name: 'dayStreak', component: <StreakCard type="day" /> },
    { name: 'tradeStreak', component: <StreakCard type="trade" /> },
  ];

  const row2components = [
    { name: 'visionScore', component: <VisionScore />, className: 'lg:col-span-1' },
    { name: 'cumulativePnl', component: <AccountBalanceChart /> },
    { name: 'dailyPnl', component: <DailyPnlChart /> },
  ]

  const calendarComponent = { name: 'calendar', component: <TradeCalendar /> };
  
  const largeWidgetComponents = [
    { name: 'winLoss', component: <WinLossChart />, className: 'lg:col-span-2' },
    { name: 'winRateStats', component: <WinRateStats />, className: 'lg:col-span-2' },
  ];
  
  const recentTradesComponent = { name: 'recentTrades', component: <RecentTrades /> };

  const visibleStatCards = statCardComponents.filter(c => visibleComponents[c.name as keyof typeof visibleComponents]);
  const visibleRow2Components = row2components.filter(c => visibleComponents[c.name as keyof typeof visibleComponents]);
  const isCalendarVisible = visibleComponents['calendar' as keyof typeof visibleComponents];
  const isRecentTradesVisible = visibleComponents['recentTrades' as keyof typeof visibleComponents];
  const visibleLargeWidgets = largeWidgetComponents.filter(c => visibleComponents[c.name as keyof typeof visibleComponents]);

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header title="Dashboard" />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="grid grid-cols-[repeat(auto-fit,minmax(220px,1fr))] gap-4">
          {visibleStatCards.map(({ name, component }) => (
            <div key={name}>
              {component}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-[repeat(auto-fit,minmax(350px,1fr))] gap-4 md:gap-8">
          {visibleRow2Components.map(({ name, component, className }) => (
            <div key={name} className={cn(className)}>
              {component}
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 items-start gap-4 md:gap-8 lg:grid-cols-10">
            {isRecentTradesVisible && (
                <div className="grid h-full auto-rows-fr gap-4 md:gap-8 lg:col-span-3">
                    {recentTradesComponent.component}
                </div>
            )}
            {isCalendarVisible && (
                <div className="grid h-full auto-rows-fr gap-4 md:gap-8 lg:col-span-7">
                    {calendarComponent.component}
                </div>
            )}
        </div>
        
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-8 lg:grid-cols-4">
          {visibleLargeWidgets.map(({ name, component, className }) => (
            <div key={name} className={cn('lg:col-span-2', className)}>
              {component}
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

export default function DashboardPage() {
    return (
        <DashboardProvider>
            <DashboardContent />
        </DashboardProvider>
    )
}
