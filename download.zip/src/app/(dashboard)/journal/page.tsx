'use client';

import { Header } from '@/components/app/header';
import { columns } from '@/components/app/journal/columns';
import { DataTable } from '@/components/app/journal/data-table';
import { AddTradeDialog } from '@/components/app/journal/add-trade-dialog';
import { useTrades } from '@/contexts/trade-provider';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

export default function JournalPage() {
  const { trades } = useTrades();

  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header title="Trade Journal" />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold tracking-tight">All Trades</h2>
            <div className="flex items-center gap-2">
                <Button variant="outline">
                    <Download className="mr-2 h-4 w-4" />
                    Import Trades
                </Button>
                <AddTradeDialog />
            </div>
        </div>
        <DataTable columns={columns} data={trades} />
      </main>
    </div>
  );
}
