import { Header } from '@/components/app/header';
import { TradeCalendar } from '@/components/app/calendar/trade-calendar';

export default function CalendarPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header title="Calendar" />
      <main className="flex flex-1 flex-col p-4 md:p-8">
        <TradeCalendar />
      </main>
    </div>
  );
}
