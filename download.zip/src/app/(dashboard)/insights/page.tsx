import { Header } from '@/components/app/header';
import { InsightsGenerator } from '@/components/app/insights/insights-generator';

export default function InsightsPage() {
  return (
    <div className="flex min-h-screen w-full flex-col">
      <Header title="AI Insights" />
      <main className="flex flex-1 flex-col gap-4 p-4 md:gap-8 md:p-8">
        <InsightsGenerator />
      </main>
    </div>
  );
}
