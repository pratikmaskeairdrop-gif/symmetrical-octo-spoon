'use client';

import { useState } from 'react';
import { getAiTradingInsights, type AiTradingInsightsOutput } from '@/ai/flows/ai-insights-trades';
import { useTrades } from '@/contexts/trade-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Sparkles } from 'lucide-react';

export function InsightsGenerator() {
  const { trades } = useTrades();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AiTradingInsightsOutput | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function generateInsights() {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const tradeData = JSON.stringify(trades, null, 2);
      const res = await getAiTradingInsights({ tradeData });
      setResult(res);
    } catch (e) {
      setError('Failed to generate insights. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>AI-Powered Insights</CardTitle>
        <CardDescription>
          Click the button to analyze your trading data and receive personalized insights to improve your decision-making.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <Button onClick={generateInsights} disabled={isLoading} size="lg">
          {isLoading ? (
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          ) : (
            <Sparkles className="mr-2 h-4 w-4" />
          )}
          Generate Insights
        </Button>

        {isLoading && (
          <div className="flex items-center justify-center pt-10">
            <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
          </div>
        )}
        {error && <p className="text-destructive pt-4">{error}</p>}
        {result && (
            <Card className="mt-6 bg-muted/50">
                <CardHeader>
                    <CardTitle>Your Trading Insights</CardTitle>
                </CardHeader>
                <CardContent>
                    <div className="prose prose-sm dark:prose-invert max-w-none whitespace-pre-wrap">
                        {result.insights}
                    </div>
                </CardContent>
            </Card>
        )}
      </CardContent>
    </Card>
  );
}
