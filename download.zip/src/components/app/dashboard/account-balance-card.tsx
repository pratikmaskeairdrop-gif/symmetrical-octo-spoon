
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { calculateNetPnL } from '@/lib/calculations';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { Info } from 'lucide-react';

const INITIAL_BALANCE = 100000;

export function AccountBalanceCard() {
    const { trades } = useTrades();
    const netPnl = calculateNetPnL(trades);
    const accountBalance = INITIAL_BALANCE + netPnl;

    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2 flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium">Account balance &amp; P&amp;L</CardTitle>
                <Info className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
                <div className={cn("text-2xl font-bold", netPnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400')}>
                    {accountBalance.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                </div>
                <CardDescription>
                    P&amp;L: {netPnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                </CardDescription>
            </CardContent>
        </Card>
    );
}
