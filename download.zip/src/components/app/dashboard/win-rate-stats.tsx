
'use client';

import { useState } from 'react';
import { useTrades } from '@/contexts/trade-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { calculateWinRate } from '@/lib/calculations';
import { isWithinInterval, startOfWeek, endOfWeek, startOfMonth, endOfMonth, subWeeks, subMonths } from 'date-fns';
import type { Trade } from '@/lib/types';
import { TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';

export function WinRateStats() {
  const { trades } = useTrades();
  const [period, setPeriod] = useState('all');

  const getFilteredTrades = () => {
    const now = new Date();
    if (period === 'week') {
      const start = startOfWeek(now);
      const end = endOfWeek(now);
      return trades.filter(t => isWithinInterval(new Date(t.date), { start, end }));
    }
    if (period === 'month') {
      const start = startOfMonth(now);
      const end = endOfMonth(now);
      return trades.filter(t => isWithinInterval(new Date(t.date), { start, end }));
    }
    return trades;
  };
  
  const filteredTrades = getFilteredTrades();
  const winRate = calculateWinRate(filteredTrades);
  const wins = filteredTrades.filter(t => t.pnl > 0).length;
  const losses = filteredTrades.filter(t => t.pnl < 0).length;
  const breakEvens = filteredTrades.filter(t => t.pnl === 0).length;

  return (
    <Card className="shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <div className="flex justify-between items-center">
            <CardTitle>Win Rate</CardTitle>
            <Tabs value={period} onValueChange={setPeriod} defaultValue="all">
                <TabsList>
                    <TabsTrigger value="week">Week</TabsTrigger>
                    <TabsTrigger value="month">Month</TabsTrigger>
                    <TabsTrigger value="all">All</TabsTrigger>
                </TabsList>
            </Tabs>
        </div>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2">
            <p className="text-4xl font-bold">{winRate.toFixed(1)}%</p>
            <TrendingUp className="h-5 w-5 text-green-500 dark:text-green-400" />
        </div>
        <p className="text-sm text-muted-foreground">{wins + losses + breakEvens} Trades</p>
        <div className="mt-4 h-2 w-full flex rounded-full overflow-hidden bg-gray-200 dark:bg-gray-700">
            <div className="bg-green-500 dark:bg-green-400" style={{ width: `${(wins / filteredTrades.length) * 100}%`}}></div>
            <div className="bg-red-500 dark:bg-red-400" style={{ width: `${(losses / filteredTrades.length) * 100}%`}}></div>
            <div className="bg-gray-400 dark:bg-gray-600" style={{ width: `${(breakEvens / filteredTrades.length) * 100}%`}}></div>
        </div>
        <div className="mt-2 flex justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-green-500 dark:bg-green-400"></div>Win: {wins}</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500 dark:bg-red-400"></div>Loss: {losses}</div>
            <div className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-gray-400 dark:bg-gray-600"></div>BE: {breakEvens}</div>
        </div>
      </CardContent>
    </Card>
  );
}
