
'use client';

import { useTrades } from '@/contexts/trade-provider';
import {
  calculateDayStreak,
  calculateTradeStreak,
} from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

export function StreakCard({ type }: { type: 'day' | 'trade' }) {
  const { trades } = useTrades();

  const dayStreak = calculateDayStreak(trades);
  const { currentStreak: tradeStreak } = calculateTradeStreak(trades);

  const streak = type === 'day' ? dayStreak : tradeStreak;
  const title = type === 'day' ? 'Current Day Streak' : 'Current Trade Streak';
  const unit = type === 'day' ? 'days' : 'trades';

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
        <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">{title}</CardTitle>
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold">{streak.count} {unit}</div>
            {streak.count > 0 && <Badge className={cn("mt-1", streak.type === 'W' ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300' : 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300')}>{streak.count}{streak.type}</Badge>}
        </CardContent>
    </Card>
  );
}
