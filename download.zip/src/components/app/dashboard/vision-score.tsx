
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  Radar,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from 'recharts';
import {
  calculateWinRate,
  calculateProfitFactor,
  calculateAverageWin,
  calculateAverageLoss,
} from '@/lib/calculations';
import { Progress } from '@/components/ui/progress';
import { ChartContainer, ChartTooltip, ChartTooltipContent, type ChartConfig } from '@/components/ui/chart';

const chartConfig = {
  value: {
    label: 'Value',
    color: '#3cff90',
  },
} satisfies ChartConfig;

export function VisionScore() {
  const { trades } = useTrades();

  const winRate = calculateWinRate(trades);
  const profitFactor = calculateProfitFactor(trades);
  const avgWin = calculateAverageWin(trades);
  const avgLoss = Math.abs(calculateAverageLoss(trades));

  // Mock data for other metrics for now
  const maxDrawdown = 10; // Assuming a percentage
  const recoveryFactor = 5;
  const consistency = 75; // Assuming a percentage

  const zellaData = [
    { subject: 'Win %', value: winRate, fullMark: 100 },
    { subject: 'Profit F.', value: isFinite(profitFactor) ? profitFactor * 10 : 0, fullMark: 100 },
    { subject: 'Avg W/L', value: avgLoss > 0 ? (avgWin / avgLoss) * 50 : 100, fullMark: 100 },
    { subject: 'Recovery F.', value: recoveryFactor * 10, fullMark: 100 },
    { subject: 'Drawdown', value: 100 - maxDrawdown, fullMark: 100 },
    { subject: 'Consistency', value: consistency, fullMark: 100 },
  ];

  const zellaScore = zellaData.reduce((acc, item) => acc + item.value, 0) / zellaData.length;

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <CardTitle>Zella Score</CardTitle>
        <CardDescription>A measure of your trading performance.</CardDescription>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="mx-auto aspect-square h-[300px] z-10 relative">
          <RadarChart
            data={zellaData}
            margin={{
              top: 40,
              right: 40,
              bottom: 40,
              left: 50,
            }}
          >
            <PolarGrid stroke="rgba(150,150,150,0.5)" strokeWidth={1} />
            <PolarAngleAxis dataKey="subject" stroke="hsl(var(--foreground))" />
            <PolarRadiusAxis angle={30} domain={[0, 100]} tick={false} axisLine={false} />
            <ChartTooltip
              cursor={false}
              content={<ChartTooltipContent indicator="dot" />}
            />
            <Radar 
              name="Zella Score" 
              dataKey="value" 
              stroke="var(--color-value)"
              fill="var(--color-value)"
              fillOpacity={0.2} 
              strokeWidth={2} />
          </RadarChart>
        </ChartContainer>
        <div className="pt-4">
          <div className="flex items-center justify-between gap-4">
            <p className="text-sm font-medium text-muted-foreground">Your Zella Score</p>
            <span className="text-2xl font-bold">{zellaScore.toFixed(2)}</span>
          </div>
          <Progress value={zellaScore} className="h-2 mt-2" />
        </div>
      </CardContent>
    </Card>
  );
}
