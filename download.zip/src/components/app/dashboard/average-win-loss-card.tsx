
'use client';

import { useTrades } from '@/contexts/trade-provider';
import {
  calculateAverageWin,
  calculateAverageLoss,
} from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { TrendingDown } from 'lucide-react';
import { HorizontalWinLoss } from './charts';

export function AverageWinLossCard() {
  const { trades } = useTrades();

  const avgWin = calculateAverageWin(trades);
  const avgLoss = Math.abs(calculateAverageLoss(trades));
  const avgTrade = avgWin - avgLoss;

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
        <CardHeader className="pb-2 flex-row items-center justify-between">
            <CardTitle className="text-sm font-medium">Avg win/loss trade</CardTitle>
              <TrendingDown className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
            <div className="text-2xl font-bold mb-2">${avgTrade.toFixed(2)}</div>
            <HorizontalWinLoss win={avgWin} loss={avgLoss} />
        </CardContent>
    </Card>
  );
}
