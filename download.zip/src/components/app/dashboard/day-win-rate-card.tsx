
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { calculateDayWinRate, getDayWinLossCount } from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { HalfCircleGauge } from './charts';
import { Info } from 'lucide-react';

export function DayWinRateCard() {
    const { trades } = useTrades();
    const dayWinRate = calculateDayWinRate(trades);
    const { wins, losses } = getDayWinLossCount(trades);

    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2 flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium flex items-center gap-1">Day Win %</CardTitle>
                <Info className="h-3 w-3 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center">
                <HalfCircleGauge value={dayWinRate} size={140} stroke={14} />
                 <div className="flex items-center gap-2 text-sm mt-1">
                    <span className="text-green-500 dark:text-green-400 font-semibold">{wins} Wins</span>
                    <span className="text-muted-foreground">|</span>
                    <span className="text-red-500 dark:text-red-400 font-semibold">{losses} Losses</span>
                </div>
            </CardContent>
        </Card>
    )
}
