'use client';

import React from 'react';
import { cn } from '@/lib/utils';

// ===== Half Circle Gauge (Trade Win %, Day Win %) =====
export function HalfCircleGauge({
  value = 0,
  wins = 0,
  losses = 0,
  size = 120,
  stroke = 14,
}: {
  value?: number;
  wins?: number;
  losses?: number;
  size?: number;
  stroke?: number;
}) {
  const clamped = Math.min(Math.max(value, 0), 100);
  const radius = (size - stroke) / 2;
  const circumference = Math.PI * radius;
  const progress = (clamped / 100) * circumference;

  const strokeColor =
    clamped < 40
      ? 'hsl(var(--destructive))'
      : clamped < 60
      ? '#f59e0b'
      : 'hsl(var(--chart-2))';


  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size / 2}>
        {/* background arc */}
        <path
          d={`M ${stroke / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${
            size - stroke / 2
          } ${size / 2}`}
          stroke="hsl(var(--muted))"
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
        />
        {/* value arc */}
        <path
          d={`M ${stroke / 2} ${size / 2} A ${radius} ${radius} 0 0 1 ${
            size - stroke / 2
          } ${size / 2}`}
          stroke={strokeColor}
          strokeWidth={stroke}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={`${progress} ${circumference}`}
        />
        {/* % text in the center of arc */}
        <text
          x="50%"
          y="85%"
          textAnchor="middle"
          fill="hsl(var(--foreground))"
          fontSize="16"
          fontWeight="bold"
        >
          {clamped.toFixed(1)}%
        </text>
      </svg>
    </div>
  );
}

// ===== Donut Circle Meter (Wins vs Losses) =====
export function WinLossDonut({
  positive = 0,
  negative = 0,
  size = 80,
  stroke = 10,
}: {
  positive?: number;
  negative?: number;
  size?: number;
  stroke?: number;
}) {
  const total = positive + negative;
  const pct = total > 0 ? (positive / total) * 100 : 0;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (pct / 100) * circumference;

  return (
    <div className="relative flex items-center justify-center" style={{width: size, height: size}}>
      <svg width={size} height={size}>
        {/* background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--destructive))"
          strokeOpacity="0.3"
          strokeWidth={stroke}
          fill="none"
        />
        {/* green arc */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--chart-2))"
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          strokeLinecap="round"
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center">
        <span className="text-xl font-bold">
            {pct.toFixed(0)}%
        </span>
        <span className="text-xs text-muted-foreground">Win Rate</span>
      </div>
    </div>
  );
}

// ===== Donut Meter (Profit Factor) =====
export function DonutMeter({ profit = 0, loss = 0, size = 100, stroke = 12 }) {
  const total = profit + loss;
  const profitPct = total > 0 ? (profit / total) * 100 : 0;

  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;

  const profitLength = (profitPct / 100) * circumference;
  const lossLength = circumference - profitLength;


  return (
    <div className="relative flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90">
        {/* Background circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--muted))"
          strokeWidth={stroke}
          fill="none"
        />
        {/* Loss arc (red) */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--destructive))"
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={`${circumference - profitLength} ${circumference}`}
          strokeDashoffset={0}
        />
        {/* Profit arc (green) */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="hsl(var(--chart-2))"
          strokeWidth={stroke}
          fill="none"
          strokeDasharray={`${profitLength} ${circumference}`}
          strokeLinecap="round"
        />
      </svg>
      {/* Text inside donut */}
      <div className="absolute text-center">
        <div className="font-bold text-lg">
          {isFinite(profit/loss) ? (profit / (loss === 0 ? 1 : loss)).toFixed(2) : 'N/A'}
        </div>
        <div className="text-xs text-muted-foreground">PF</div>
      </div>
    </div>
  );
}


// ===== Horizontal Win/Loss Bar (Avg Win vs Avg Loss) =====
export function HorizontalWinLoss({
  win = 0,
  loss = 0,
  height = 10,
}: {
  win?: number;
  loss?: number;
  height?: number;
}) {
  const total = win + loss;
  const winPct = total > 0 ? (win / total) * 100 : 0;

  return (
    <div className="w-full">
      <div className="flex justify-between text-sm mb-1">
        <span className="text-green-500 dark:text-green-400">${win.toFixed(2)}</span>
        <span className="text-red-500 dark:text-red-400">-${loss.toFixed(2)}</span>
      </div>
      <div
        className="w-full bg-destructive/30 rounded-full flex overflow-hidden"
        style={{ height }}
      >
        <div
          style={{ width: `${winPct}%` }}
          className="bg-green-500"
        ></div>
      </div>
    </div>
  );
}
