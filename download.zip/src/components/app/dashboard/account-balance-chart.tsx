
'use client';

import React from 'react';
import { useTrades } from '@/contexts/trade-provider';
import { calculateCumulativePnL } from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart';
import { Area, AreaChart, CartesianGrid, XAxis, YAxis } from 'recharts';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Info } from 'lucide-react';

const chartConfig = {
  pnl: {
    label: 'Cumulative P&L',
    color: '#3cff90',
  },
} satisfies ChartConfig;

export function AccountBalanceChart() {
  const { trades } = useTrades();
  const [timeRange, setTimeRange] = React.useState('all');
  
  const chartData = calculateCumulativePnL(trades, 100000);

  const filteredData = timeRange === 'all' ? chartData : chartData.filter(data => {
      const date = new Date(data.date);
      const monthsAgo = new Date();
      monthsAgo.setMonth(monthsAgo.getMonth() - parseInt(timeRange));
      return date >= monthsAgo;
  });

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <div className="flex justify-between items-start">
            <div className='flex items-center gap-1'>
                <CardTitle>Daily net cumulative P&amp;L</CardTitle>
                <Info className="h-3 w-3 text-muted-foreground" />
            </div>
            <Select value={timeRange} onValueChange={setTimeRange}>
              <SelectTrigger className="w-[120px] h-8 text-xs">
                <SelectValue placeholder="Time range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="1">Last 1M</SelectItem>
                <SelectItem value="3">Last 3M</SelectItem>
                <SelectItem value="6">Last 6M</SelectItem>
                <SelectItem value="12">Last 1Y</SelectItem>
                <SelectItem value="all">All time</SelectItem>
              </SelectContent>
            </Select>
        </div>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <AreaChart data={filteredData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <defs>
                  <linearGradient id="fillPnl" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="var(--color-pnl)" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="var(--color-pnl)" stopOpacity={0.1}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsla(var(--foreground), 0.1)" />
                <XAxis
                    dataKey="date"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(value) => `$${(value/1000).toLocaleString()}K`}
                  domain={['dataMin - 1000', 'dataMax + 1000']}
                />
                <ChartTooltip
                    cursor={false}
                    content={<ChartTooltipContent indicator="dot" />}
                />
                <Area
                    dataKey="pnl"
                    type="monotone"
                    stroke="var(--color-pnl)"
                    strokeWidth={2}
                    dot={false}
                    fillOpacity={1} 
                    fill="url(#fillPnl)"
                />
            </AreaChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
