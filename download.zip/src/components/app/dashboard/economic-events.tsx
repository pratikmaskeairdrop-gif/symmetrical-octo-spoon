'use client';

import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { ExternalLink, Flag } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const mockEvents = [
    {
        date: "Monday, September 29, 2025",
        events: [
            { time: "8:30 AM", name: "Unemployment Claims", impact: "High", forecast: "230K", previous: "235K" },
            { time: "8:30 AM", name: "Philadelphia Fed Manufacturing Index", impact: "Medium", forecast: "12.0", previous: "10.5" },
            { time: "10:00 AM", name: "Existing Home Sales", impact: "Low", forecast: "4.25M", previous: "4.22M" },
        ]
    },
    {
        date: "Tuesday, September 30, 2025",
        events: [
            { time: "10:00 AM", name: "CB Consumer Confidence", impact: "Medium", forecast: "105.5", previous: "106.1" },
        ]
    }
]

export function EconomicEvents() {
  const getImpactColor = (impact: string) => {
    switch (impact.toLowerCase()) {
      case 'high': return 'bg-red-500';
      case 'medium': return 'bg-orange-500';
      case 'low': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>$ USD Economic Events (mock data)</CardTitle>
        <div className="flex justify-between items-center">
            <a href="#" className="text-xs text-primary hover:underline flex items-center gap-1">
                View full calendar <ExternalLink className="h-3 w-3" />
            </a>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><div className="h-2 w-2 rounded-full bg-red-500"></div>High</span>
                <span className="flex items-center gap-1"><div className="h-2 w-2 rounded-full bg-orange-500"></div>Medium</span>
                <span className="flex items-center gap-1"><div className="h-2 w-2 rounded-full bg-yellow-500"></div>Low</span>
            </div>
        </div>
      </CardHeader>
      <CardContent>
        <Accordion type="multiple" defaultValue={["Monday, September 29, 2025"]} className="w-full">
            {mockEvents.map(day => (
                <AccordionItem value={day.date} key={day.date}>
                    <AccordionTrigger>{day.date}</AccordionTrigger>
                    <AccordionContent>
                        <div className="space-y-4">
                        {day.events.map(event => (
                            <div key={event.name} className="flex items-start gap-4">
                                <div className="text-xs text-muted-foreground pt-1">{event.time}</div>
                                <div className="flex-1">
                                    <div className="flex items-center gap-2">
                                        <div className={cn("w-2 h-2 rounded-full", getImpactColor(event.impact))}></div>
                                        <p className="font-semibold text-sm">{event.name}</p>
                                    </div>
                                    <p className="text-xs text-muted-foreground">F: {event.forecast} P: {event.previous}</p>
                                </div>
                            </div>
                        ))}
                        </div>
                    </AccordionContent>
                </AccordionItem>
            ))}
        </Accordion>
      </CardContent>
    </Card>
  );
}
