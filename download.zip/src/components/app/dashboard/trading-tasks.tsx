'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Plus, Trash2 } from 'lucide-react';

type Task = {
  id: number;
  text: string;
  completed: boolean;
};

export function TradingTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [inputValue, setInputValue] = useState('');

  const handleAddTask = () => {
    if (inputValue.trim()) {
      setTasks([...tasks, { id: Date.now(), text: inputValue, completed: false }]);
      setInputValue('');
    }
  };

  const handleToggleTask = (id: number) => {
    setTasks(
      tasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };
  
    const handleDeleteTask = (id: number) => {
    setTasks(tasks.filter(task => task.id !== id));
  };


  return (
    <Card>
      <CardHeader>
        <CardTitle>Trading Tasks</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Input 
            placeholder="Add task..." 
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleAddTask()}
            />
          <Button onClick={handleAddTask} size="icon" variant="outline">
            <Plus className="h-4 w-4" />
          </Button>
        </div>
        <div className="space-y-2">
            {tasks.length > 0 ? (
                tasks.map(task => (
                    <div key={task.id} className="flex items-center gap-2 group">
                    <Checkbox
                        id={`task-${task.id}`}
                        checked={task.completed}
                        onCheckedChange={() => handleToggleTask(task.id)}
                    />
                    <label
                        htmlFor={`task-${task.id}`}
                        className={`flex-1 text-sm ${task.completed ? 'line-through text-muted-foreground' : ''}`}
                    >
                        {task.text}
                    </label>
                     <Button variant="ghost" size="icon" className="h-6 w-6 opacity-0 group-hover:opacity-100" onClick={() => handleDeleteTask(task.id)}>
                        <Trash2 className="h-4 w-4 text-destructive" />
                    </Button>
                    </div>
                ))
            ) : (
                <p className="text-sm text-muted-foreground text-center py-4">No tasks for today. Add some tasks to track your progress.</p>
            )}
        </div>
      </CardContent>
    </Card>
  );
}
