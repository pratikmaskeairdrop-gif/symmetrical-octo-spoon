
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from '@/components/ui/chart';
import { Bar, BarChart, CartesianGrid, XAxis, YAxis, ResponsiveContainer, Cell } from 'recharts';
import { Info } from 'lucide-react';
import { useMemo } from 'react';
import { format } from 'date-fns';

const chartConfig = {
  pnl: {
    label: 'Net P&L',
  },
} satisfies ChartConfig;


export function DailyPnlChart() {
  const { trades } = useTrades();
  
  const chartData = useMemo(() => {
    const dailyPnl: { [key: string]: number } = {};
    trades.forEach(trade => {
      const day = format(new Date(trade.date), 'yyyy-MM-dd');
      dailyPnl[day] = (dailyPnl[day] || 0) + trade.pnl;
    });

    return Object.entries(dailyPnl)
      .map(([date, pnl]) => ({ date, pnl }))
      .sort((a,b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [trades]);


  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <div className="flex items-center gap-1">
            <CardTitle>Net daily P&amp;L</CardTitle>
            <Info className="h-3 w-3 text-muted-foreground" />
        </div>
      </CardHeader>
      <CardContent>
        <ChartContainer config={chartConfig} className="h-[300px] w-full">
            <BarChart data={chartData} margin={{ top: 5, right: 20, left: -10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="hsla(var(--foreground), 0.1)" />
                <XAxis
                    dataKey="date"
                    tickLine={false}
                    axisLine={false}
                    tickMargin={8}
                    tickFormatter={(value) => new Date(value).toLocaleDateString('en-US', { month: '2-digit', day: '2-digit' })}
                />
                <YAxis
                  tickLine={false}
                  axisLine={false}
                  tickMargin={8}
                  tickFormatter={(value) => `$${(value/1000).toLocaleString()}K`}
                />
                <ChartTooltip
                    cursor={false}
                    content={<ChartTooltipContent indicator="dot" />}
                />
                <Bar dataKey="pnl">
                    {chartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.pnl >= 0 ? '#3cff90' : '#ff2d0f'} />
                    ))}
                </Bar>
            </BarChart>
        </ChartContainer>
      </CardContent>
    </Card>
  );
}
