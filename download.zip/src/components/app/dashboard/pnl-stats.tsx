
'use client';

import { useMemo } from 'react';
import { useTrades } from '@/contexts/trade-provider';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { calculateNetPnL } from '@/lib/calculations';
import { isWithinInterval, startOfMonth, endOfMonth, subMonths } from 'date-fns';
import { cn } from '@/lib/utils';

export function PnlStats() {
  const { trades } = useTrades();

  const netPnl = useMemo(() => calculateNetPnL(trades), [trades]);

  const pnlChange = useMemo(() => {
    const lastMonthStart = startOfMonth(subMonths(new Date(), 1));
    const lastMonthEnd = endOfMonth(subMonths(new Date(), 1));
    const lastMonthTrades = trades.filter(trade => isWithinInterval(new Date(trade.date), { start: lastMonthStart, end: lastMonthEnd }));
    const lastMonthPnl = calculateNetPnL(lastMonthTrades);
    const currentMonthStart = startOfMonth(new Date());
    const currentMonthEnd = endOfMonth(new Date());
    const currentMonthTrades = trades.filter(trade => isWithinInterval(new Date(trade.date), { start: currentMonthStart, end: currentMonthEnd }));
    const currentMonthPnl = calculateNetPnL(currentMonthTrades);
    
    if (lastMonthPnl === 0) {
        return currentMonthPnl;
    }
    return currentMonthPnl - lastMonthPnl;
  }, [trades]);

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <CardTitle>Net P&amp;L</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-baseline gap-2">
            <p className={cn("text-2xl font-bold", netPnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400')}>
                {netPnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
            </p>
        </div>
        <CardDescription>
            <span className={cn(pnlChange >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400")}>
                {pnlChange >= 0 ? '+' : ''}{pnlChange.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
            </span>
            {' '}from last month
        </CardDescription>
      </CardContent>
    </Card>
  );
}
