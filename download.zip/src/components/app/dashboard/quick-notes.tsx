'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { useState } from 'react';

export function QuickNotes() {
    const [note, setNote] = useState('');
    const [savedNote, setSavedNote] = useState('');

    const handleSave = () => {
        setSavedNote(note);
    };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Notes</CardTitle>
      </CardHeader>
      <CardContent>
        <Textarea 
            placeholder="Note:" 
            value={note}
            onChange={(e) => setNote(e.target.value)}
            className="mb-2"
        />
        <Button onClick={handleSave} size="sm">Save Note</Button>
        {savedNote && (
            <div className="mt-4 p-2 border rounded-md bg-muted">
                <p className="text-sm text-muted-foreground">{savedNote}</p>
            </div>
        )}
      </CardContent>
    </Card>
  );
}
