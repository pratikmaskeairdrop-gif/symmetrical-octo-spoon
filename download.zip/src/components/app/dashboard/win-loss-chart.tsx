
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { getWinLossCount } from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { WinLossDonut } from './charts';

export function WinLossChart() {
  const { trades } = useTrades();
  const { wins, losses } = getWinLossCount(trades);

  return (
    <Card className="shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader>
        <CardTitle>Win / Loss Ratio</CardTitle>
        <CardDescription>A breakdown of your winning and losing trades.</CardDescription>
      </CardHeader>
      <CardContent className="flex items-center justify-center h-[250px]">
        <WinLossDonut positive={wins} negative={losses} size={150} stroke={20} />
      </CardContent>
    </Card>
  );
}
