
'use client';

import { useTrades } from '@/contexts/trade-provider';
import {
  calculateNetPnL,
  calculateWinRate,
  calculateProfitFactor,
  getWinLossCount,
} from '@/lib/calculations';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Info, TrendingUp } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useMemo } from 'react';
import { subMonths, isWithinInterval, startOfMonth, endOfMonth } from 'date-fns';
import { HalfCircleGauge } from './charts';

export function NetPnlCard() {
    const { trades } = useTrades();
    const netPnl = calculateNetPnL(trades);
    const lastMonthStart = startOfMonth(subMonths(new Date(), 1));
    const lastMonthEnd = endOfMonth(subMonths(new Date(), 1));
    const lastMonthTrades = trades.filter(trade => isWithinInterval(new Date(trade.date), { start: lastMonthStart, end: lastMonthEnd }));
    const lastMonthPnl = calculateNetPnL(lastMonthTrades);
    const pnlChange = netPnl - lastMonthPnl;


    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Net P&L</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex items-baseline gap-2">
                    <div className={cn("text-2xl font-bold", netPnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400')}>
                        {netPnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                    </div>
                </div>
                <CardDescription>
                    <span className={cn(pnlChange >= 0 ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400")}>
                        {pnlChange >= 0 ? '+' : ''}{pnlChange.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                    </span>
                    {' '}from last month
                </CardDescription>
            </CardContent>
        </Card>
    );
}

export function MonthlyPnlCard() {
    const { trades } = useTrades();
    const monthlyPnl = useMemo(() => {
        const currentMonthStart = startOfMonth(new Date());
        const currentMonthEnd = endOfMonth(new Date());
        const monthlyTrades = trades.filter(trade => isWithinInterval(new Date(trade.date), { start: currentMonthStart, end: currentMonthEnd }));
        return calculateNetPnL(monthlyTrades);
    }, [trades]);

    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Monthly PnL</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex items-baseline gap-2">
                    <div className={cn("text-2xl font-bold", monthlyPnl >= 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400')}>
                        {monthlyPnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                    </div>
                    <TrendingUp className={cn("h-5 w-5", monthlyPnl >= 0 ? 'text-green-500 dark:text-green-400' : 'text-red-500 dark:text-red-400 transform rotate-180')} />
                </div>
                <CardDescription>This month</CardDescription>
            </CardContent>
        </Card>
    );
}

export function TradeWinRateCard() {
    const { trades } = useTrades();
    const winRate = calculateWinRate(trades);
    const { wins, losses } = getWinLossCount(trades);

    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2 flex-row items-center justify-between">
                <CardTitle className="text-sm font-medium flex items-center gap-1">Trade Win %</CardTitle>
                <Info className="h-3 w-3 text-muted-foreground" />
            </CardHeader>
            <CardContent className="flex flex-col items-center justify-center">
                 <HalfCircleGauge value={winRate} size={140} stroke={14} />
                 <div className="flex items-center gap-2 text-sm mt-1">
                    <span className="text-green-500 dark:text-green-400 font-semibold">{wins} Wins</span>
                    <span className="text-muted-foreground">|</span>
                    <span className="text-red-500 dark:text-red-400 font-semibold">{losses} Losses</span>
                </div>
            </CardContent>
        </Card>
    )
}

export function ProfitFactorCard() {
    const { trades } = useTrades();
    const profitFactor = calculateProfitFactor(trades);
    
    return (
        <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
            <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
            </CardHeader>
            <CardContent>
                 <div className="flex items-center gap-4">
                    <div className="text-2xl font-bold">{isFinite(profitFactor) ? profitFactor.toFixed(2) : 'N/A'}</div>
                </div>
                <CardDescription>Gross profit / Gross loss</CardDescription>
            </CardContent>
      </Card>
    )
}
