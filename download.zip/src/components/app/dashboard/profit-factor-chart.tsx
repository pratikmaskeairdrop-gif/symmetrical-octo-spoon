
'use client';

import { useTrades } from '@/contexts/trade-provider';
import { getWinLossCount } from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { DonutMeter } from './charts';

export function ProfitFactorChart() {
  const { trades } = useTrades();
  const grossProfit = trades
    .filter((trade) => trade.pnl > 0)
    .reduce((acc, trade) => acc + trade.pnl, 0);
  const grossLoss = Math.abs(
    trades
      .filter((trade) => trade.pnl < 0)
      .reduce((acc, trade) => acc + trade.pnl, 0)
  );

  return (
    <Card className="h-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">Profit Factor</CardTitle>
      </CardHeader>
      <CardContent className="flex items-center justify-center">
        <DonutMeter profit={grossProfit} loss={grossLoss} size={100} stroke={12} />
      </CardContent>
    </Card>
  );
}
