
'use client';

import { SidebarTrigger } from '@/components/ui/sidebar';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuCheckboxItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { ThemeSwitcher } from './theme-switcher';
import { useDashboard } from '@/contexts/dashboard-provider';
import { View } from 'lucide-react';
import { usePathname } from 'next/navigation';

export function Header({ title }: { title: string }) {
  const userAvatar = PlaceHolderImages.find((img) => img.id === 'user-avatar');
  const { visibleComponents, toggleComponentVisibility } = useDashboard();
  const pathname = usePathname();

  const isDashboard = pathname === '/dashboard';

  return (
    <header className="flex h-16 items-center gap-4 border-b bg-card px-4 md:px-6">
      <SidebarTrigger />
      <h1 className="text-lg font-semibold md:text-xl">{title}</h1>
      <div className="ml-auto flex items-center gap-2">
        {isDashboard && (
            <>
                <DropdownMenu>
                <DropdownMenuTrigger asChild>
                    <Button variant="outline">
                        <View className="mr-2 h-4 w-4" />
                        View
                    </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                    <DropdownMenuLabel>Toggle Dashboard Widgets</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <DropdownMenuCheckboxItem checked={visibleComponents.pnlStats} onCheckedChange={() => toggleComponentVisibility('pnlStats')}>P&amp;L Stats</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.tradeWinRate} onCheckedChange={() => toggleComponentVisibility('tradeWinRate')}>Trade Win %</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.dayWinRate} onCheckedChange={() => toggleComponentVisibility('dayWinRate')}>Day Win %</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.profitFactor} onCheckedChange={() => toggleComponentVisibility('profitFactor')}>Profit Factor</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.avgWinLoss} onCheckedChange={() => toggleComponentVisibility('avgWinLoss')}>Avg. Win/Loss</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.accountBalance} onCheckedChange={() => toggleComponentVisibility('accountBalance')}>Account Balance</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.dayStreak} onCheckedChange={() => toggleComponentVisibility('dayStreak')}>Day Streak</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.tradeStreak} onCheckedChange={() => toggleComponentVisibility('tradeStreak')}>Trade Streak</DropdownMenuCheckboxItem>
                    <DropdownMenuSeparator />
                    <DropdownMenuCheckboxItem checked={visibleComponents.visionScore} onCheckedChange={() => toggleComponentVisibility('visionScore')}>Zella Score</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.cumulativePnl} onCheckedChange={() => toggleComponentVisibility('cumulativePnl')}>Daily Net Cumulative P&L</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.dailyPnl} onCheckedChange={() => toggleComponentVisibility('dailyPnl')}>Net Daily P&L</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.calendar} onCheckedChange={() => toggleComponentVisibility('calendar')}>Calendar</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.winLoss} onCheckedChange={() => toggleComponentVisibility('winLoss')}>Win/Loss Ratio</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.winRateStats} onCheckedChange={() => toggleComponentVisibility('winRateStats')}>Win Rate Stats</DropdownMenuCheckboxItem>
                    <DropdownMenuCheckboxItem checked={visibleComponents.recentTrades} onCheckedChange={() => toggleComponentVisibility('recentTrades')}>Recent Trades</DropdownMenuCheckboxItem>
                </DropdownMenuContent>
                </DropdownMenu>
            </>
        )}
        <ThemeSwitcher />
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="relative h-10 w-10 rounded-full">
              <Avatar className="h-10 w-10">
                {userAvatar && <AvatarImage src={userAvatar.imageUrl} alt={userAvatar.description} data-ai-hint={userAvatar.imageHint} />}
                <AvatarFallback>TV</AvatarFallback>
              </Avatar>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>My Account</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Settings</DropdownMenuItem>
            <DropdownMenuItem>Support</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
}
