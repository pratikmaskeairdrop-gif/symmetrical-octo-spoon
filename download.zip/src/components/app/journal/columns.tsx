'use client';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import type { Trade } from '@/lib/types';
import { cn } from '@/lib/utils';
import { MoreHorizontal } from 'lucide-react';

// This is a simplified column definition without using @tanstack/react-table
// to avoid adding new dependencies.

export type ColumnDef<TData> = {
  accessorKey: keyof TData | 'actions';
  header: string;
  cell: ({ row }: { row: TData }) => React.ReactNode;
};

export const columns: ColumnDef<Trade>[] = [
  {
    accessorKey: 'instrument',
    header: 'Instrument',
    cell: ({ row }) => <div className="font-medium">{row.instrument}</div>,
  },
  {
    accessorKey: 'date',
    header: 'Date',
    cell: ({ row }) => (
      <div>{new Date(row.date).toLocaleDateString()}</div>
    ),
  },
  {
    accessorKey: 'direction',
    header: 'Direction',
    cell: ({ row }) => (
      <Badge
        variant="outline"
        className={cn(
          row.direction === 'Long'
            ? 'border-green-500 text-green-500'
            : 'border-red-500 text-red-500'
        )}
      >
        {row.direction}
      </Badge>
    ),
  },
  {
    accessorKey: 'entryPrice',
    header: 'Entry Price',
    cell: ({ row }) => <div>{row.entryPrice.toFixed(2)}</div>,
  },
  {
    accessorKey: 'exitPrice',
    header: 'Exit Price',
    cell: ({ row }) => <div>{row.exitPrice.toFixed(2)}</div>,
  },
  {
    accessorKey: 'size',
    header: 'Size',
    cell: ({ row }) => <div>{row.size}</div>,
  },
  {
    accessorKey: 'pnl',
    header: 'P&L',
    cell: ({ row }) => (
      <div
        className={cn(
          'font-medium',
          row.pnl >= 0 ? 'text-green-600' : 'text-red-600'
        )}
      >
        {row.pnl.toLocaleString('en-US', {
          style: 'currency',
          currency: 'USD',
        })}
      </div>
    ),
  },
  {
    accessorKey: 'actions',
    header: 'Actions',
    cell: ({ row }) => {
      return (
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" className="h-8 w-8 p-0">
              <span className="sr-only">Open menu</span>
              <MoreHorizontal className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuLabel>Actions</DropdownMenuLabel>
            <DropdownMenuItem
              onClick={() => navigator.clipboard.writeText(row.id)}
            >
              Copy trade ID
            </DropdownMenuItem>
            <DropdownMenuItem>View details</DropdownMenuItem>
            <DropdownMenuItem>Edit trade</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      );
    },
  },
];
