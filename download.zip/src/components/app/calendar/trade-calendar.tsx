
'use client';

import * as React from 'react';
import { useTrades } from '@/contexts/trade-provider';
import type { Trade } from '@/lib/types';
import { cn } from '@/lib/utils';
import {
  format,
  startOfMonth,
  endOfMonth,
  eachDayOfInterval,
  startOfWeek,
  endOfWeek,
  isSameMonth,
  addMonths,
  subMonths,
} from 'date-fns';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Settings, Info, Calendar as CalendarIcon } from 'lucide-react';
import { Calendar } from '@/components/ui/calendar';

function formatValue(value: number, unit: 'currency' | 'r-unit'): string {
  if (unit === 'r-unit') {
    return `${value.toFixed(1)}R`;
  }
  if (Math.abs(value) >= 1000) {
    const num = (value / 1000).toFixed(1);
    return `${value < 0 ? '-' : ''}$${Math.abs(Number(num))}k`;
  }
  return `$${value.toFixed(0)}`;
}

const weekDays = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

export function TradeCalendar() {
  const { trades } = useTrades();
  const [month, setMonth] = React.useState(new Date());
  const [displayUnit, setDisplayUnit] = React.useState<'currency' | 'r-unit'>('currency');
  const [isClient, setIsClient] = React.useState(false);

  React.useEffect(() => {
    setIsClient(true);
  }, []);

  const tradesByDate = React.useMemo(() => {
    const map = new Map<string, { trades: Trade[]; pnl: number; rValue: number; wins: number; }>();
    if (!isClient) return map;
    trades.forEach((trade) => {
      const tradeDate = format(new Date(trade.date), 'yyyy-MM-dd');
      if (!map.has(tradeDate)) {
        map.set(tradeDate, { trades: [], pnl: 0, rValue: 0, wins: 0 });
      }
      const dayData = map.get(tradeDate)!;
      dayData.trades.push(trade);
      dayData.pnl += trade.pnl;
      dayData.rValue += trade.rValue ?? 0;
      if (trade.pnl > 0) dayData.wins++;
    });
    return map;
  }, [trades, isClient]);

  const calendarGrid = React.useMemo(() => {
    if (!isClient) return [];
    
    const monthStart = startOfMonth(month);
    const monthEnd = endOfMonth(month);
    const startDate = startOfWeek(monthStart);
    const endDate = endOfWeek(monthEnd);

    const days = eachDayOfInterval({ start: startDate, end: endDate });
    const weeks: Date[][] = [];

    for (let i = 0; i < days.length; i += 7) {
      weeks.push(days.slice(i, i + 7));
    }
    
    return weeks;
  }, [month, isClient]);

  const handleMonthChange = (newMonth: Date) => {
    setMonth(newMonth);
  };

  const monthlyTrades = React.useMemo(
    () =>
      isClient ? trades.filter((trade) =>
        isSameMonth(new Date(trade.date), month)
      ) : [],
    [trades, month, isClient]
  );
  
  const monthlyPnl = monthlyTrades.reduce((acc, t) => acc + t.pnl, 0);
  const monthlyRValue = monthlyTrades.reduce((acc, t) => acc + (t.rValue ?? 0), 0);
  const monthlyTradingDays = new Set(monthlyTrades.map(t => format(new Date(t.date), 'yyyy-MM-dd'))).size;

  if (!isClient) {
    return (
      <div className="bg-card p-4 sm:p-6 rounded-lg shadow-sm w-full">
        <div className="animate-pulse">
          <div className="h-10 bg-muted rounded-md w-full mb-4"></div>
          <div className="h-80 bg-muted rounded-md w-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="calendar-wrapper p-4 sm:p-6 rounded-lg w-full shadow-lg shadow-green-500/10 dark:shadow-green-400/20">
       <div className="flex flex-col sm:flex-row justify-between items-center mb-4 gap-4">
          <div className="flex items-center gap-2">
              <Button variant="outline" size="icon" onClick={() => handleMonthChange(subMonths(month, 1))}>
                  <ChevronLeft className="h-4 w-4" />
              </Button>
              
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full sm:w-auto justify-start text-left font-normal">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(month, 'MMMM yyyy')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={month}
                    onSelect={(day) => day && setMonth(day)}
                    initialFocus
                    captionLayout="dropdown-buttons"
                    fromYear={2020}
                    toYear={new Date().getFullYear() + 5}
                  />
                </PopoverContent>
              </Popover>

              <Button variant="outline" size="icon" onClick={() => handleMonthChange(addMonths(month, 1))}>
                  <ChevronRight className="h-4 w-4" />
              </Button>
              <Button variant="outline" onClick={() => setMonth(new Date())}>Today</Button>
          </div>
          <div className="flex items-center gap-4 text-sm">
              <span className="font-medium">Monthly stats:</span>
              <span className={cn(monthlyPnl >= 0 ? "text-green-600" : "text-red-600", "font-semibold")}>
                {formatValue(displayUnit === 'currency' ? monthlyPnl : monthlyRValue, displayUnit)}
              </span>
              <span className="text-muted-foreground">{monthlyTradingDays} days</span>
              <Select value={displayUnit} onValueChange={(value: 'currency' | 'r-unit') => setDisplayUnit(value)}>
                  <SelectTrigger className="w-24 h-8 text-xs">
                      <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                      <SelectItem value="currency">$ (Currency)</SelectItem>
                      <SelectItem value="r-unit">R (Risk Units)</SelectItem>
                  </SelectContent>
              </Select>
              <Settings className="h-5 w-5 text-muted-foreground cursor-pointer" />
              <Info className="h-5 w-5 text-muted-foreground cursor-pointer" />
          </div>
      </div>
      <div className="grid grid-cols-8 gap-2">
        {weekDays.map(day => (
          <div key={day} className="text-center text-muted-foreground font-semibold text-sm pb-2">{day}</div>
        ))}
        <div className="text-center text-muted-foreground font-semibold text-sm pb-2">Weekly</div>
        {calendarGrid.flat().map((day, index) => {
          const dayStr = format(day, 'yyyy-MM-dd');
          const dayData = tradesByDate.get(dayStr);
          const dayPnl = dayData?.pnl ?? 0;
          const isCurrentMonth = isSameMonth(day, month);

          const dayCell = (
            <div className={cn(
              "h-auto min-h-[120px] w-full text-sm p-1 flex flex-col justify-start items-end rounded-md bg-card/50",
              !isCurrentMonth && 'text-muted-foreground bg-card/20',
              dayPnl > 0 && 'profit-day',
              dayPnl < 0 && 'loss-day',
              dayPnl !== 0 ? 'border' : 'border border-transparent'
            )}>
              <div className="self-end font-semibold text-xs">{format(day, 'd')}</div>
              {dayData && (
                <div className="mt-auto text-left w-full">
                  <p className={cn('font-bold text-base', dayPnl > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400')}>
                    {formatValue(displayUnit === 'currency' ? dayPnl : dayData.rValue, displayUnit)}
                  </p>
                  <p className="text-xs text-muted-foreground">{dayData.trades.length} trade{dayData.trades.length > 1 ? 's' : ''}</p>
                  <p className="text-xs text-muted-foreground">
                    {((dayData.wins / dayData.trades.length) * 100).toFixed(0)}%
                  </p>
                </div>
              )}
            </div>
          );

          const isWeekEnd = (index + 1) % 7 === 0;

          return (
            <React.Fragment key={dayStr}>
              {dayData ? (
                <Popover>
                  <PopoverTrigger asChild>
                    <div className="w-full h-full cursor-pointer">{dayCell}</div>
                  </PopoverTrigger>
                  <PopoverContent className="w-96">
                    <h4 className="font-semibold mb-2">Trades for {format(day, 'MMMM d, yyyy')}</h4>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Symbol</TableHead>
                          <TableHead>Direction</TableHead>
                          <TableHead className="text-right">P&L</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {dayData.trades.map(trade => (
                          <TableRow key={trade.id}>
                            <TableCell>{trade.instrument}</TableCell>
                            <TableCell>{trade.direction}</TableCell>
                            <TableCell className={cn('text-right', trade.pnl >= 0 ? 'text-green-600' : 'text-red-600')}>
                              {trade.pnl.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </PopoverContent>
                </Popover>
              ) : (
                dayCell
              )}
              
              {isWeekEnd && (() => {
                  const weekStart = startOfWeek(day);
                  const weekEnd = endOfWeek(day);
                  const weekTrades = trades.filter(t => {
                      const tradeDate = new Date(t.date);
                      return tradeDate >= weekStart && tradeDate <= weekEnd && isSameMonth(tradeDate, month);
                  });
                  const weeklyPnl = weekTrades.reduce((acc, t) => acc + t.pnl, 0);
                  const weeklyRValue = weekTrades.reduce((acc, t) => acc + (t.rValue ?? 0), 0);
                  const tradedDays = new Set(weekTrades.map(t => format(new Date(t.date), 'yyyy-MM-dd'))).size;

                  return (
                    <div className={cn("p-3 rounded-md flex-1 min-h-[120px] flex flex-col justify-center", 
                        weeklyPnl > 0 ? "bg-green-50 dark:bg-green-900/20" 
                        : weeklyPnl < 0 ? "bg-red-50 dark:bg-red-900/20" 
                        : "bg-muted/50"
                    )}>
                      <p className="font-semibold text-sm">Week</p>
                      <p className={cn("font-bold text-lg", weeklyPnl > 0 ? "text-green-600" : weeklyPnl < 0 ? "text-red-600" : "")}>
                        {formatValue(displayUnit === 'currency' ? weeklyPnl : weeklyRValue, displayUnit)}
                      </p>
                      <p className="text-xs text-muted-foreground">{tradedDays} day{tradedDays === 1 ? '' : 's'}</p>
                    </div>
                  );
              })()}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
