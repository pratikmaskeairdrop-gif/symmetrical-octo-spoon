'use client';

import { useTrades } from '@/contexts/trade-provider';
import {
  calculateNetPnL,
  calculateWinRate,
  calculateProfitFactor,
  calculateAverageWin,
  calculateAverageLoss,
  calculateDayStreak,
  calculateTradeStreak,
} from '@/lib/calculations';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown } from 'lucide-react';


export function CalendarStats() {
  const { trades } = useTrades();

  const netPnl = calculateNetPnL(trades);
  const winRate = calculateWinRate(trades);
  const profitFactor = calculateProfitFactor(trades);
  const avgWin = calculateAverageWin(trades);
  const avgLoss = Math.abs(calculateAverageLoss(trades));
  const dayStreak = calculateDayStreak(trades);
  const { currentStreak: tradeStreak } = calculateTradeStreak(trades);
  
  const totalAvg = avgWin + avgLoss;
  const avgWinPercentage = totalAvg > 0 ? (avgWin / totalAvg) * 100 : 0;
  const avgTrade = avgWin - avgLoss;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-4">
    </div>
  );
}
