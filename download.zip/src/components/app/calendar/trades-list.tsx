'use client';

import { useTrades } from '@/contexts/trade-provider';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"

export function TradesList() {
  const { trades } = useTrades();
  const sortedTrades = [...trades].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

  return (
    <Card className="h-full">
        <Tabs defaultValue="recent" className="w-full">
            <CardHeader>
                <CardTitle>Trades</CardTitle>
                <TabsList className="grid w-full grid-cols-2 mt-2">
                    <TabsTrigger value="recent">Recent</TabsTrigger>
                    <TabsTrigger value="open" disabled>Open Positions</TabsTrigger>
                </TabsList>
            </CardHeader>
            <CardContent className="p-0">
                <ScrollArea className="h-[calc(100vh_-_240px)]">
                    <TabsContent value="recent">
                        <Table>
                            <TableHeader>
                            <TableRow>
                                <TableHead>Symbol</TableHead>
                                <TableHead>Close Date</TableHead>
                                <TableHead className="text-right">Net P&L</TableHead>
                            </TableRow>
                            </TableHeader>
                            <TableBody>
                            {sortedTrades.map((trade) => (
                                <TableRow key={trade.id}>
                                <TableCell>
                                    <div className="font-medium">{trade.instrument}</div>
                                </TableCell>
                                <TableCell className="text-muted-foreground">
                                    {new Date(trade.date).toLocaleDateString('en-US', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                                </TableCell>
                                <TableCell
                                    className={cn(
                                    'text-right font-medium',
                                    trade.pnl >= 0 ? 'text-green-600' : 'text-red-600'
                                    )}
                                >
                                    {trade.pnl.toLocaleString('en-US', {
                                    style: 'currency',
                                    currency: 'USD',
                                    })}
                                </TableCell>
                                </TableRow>
                            ))}
                            </TableBody>
                        </Table>
                    </TabsContent>
                </ScrollArea>
            </CardContent>
        </Tabs>
    </Card>
  );
}
