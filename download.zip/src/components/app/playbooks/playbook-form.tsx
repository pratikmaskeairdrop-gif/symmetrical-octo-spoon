'use client';

import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { generatePlaybook, type GeneratePlaybookOutput } from '@/ai/flows/playbook-generation';
import { useTrades } from '@/contexts/trade-provider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Loader2, Wand2 } from 'lucide-react';
import { Textarea } from '@/components/ui/textarea';

const playbookFormSchema = z.object({
  strategy: z.string().min(3, 'Please enter a strategy or instrument.'),
});

type PlaybookFormValues = z.infer<typeof playbookFormSchema>;

export function PlaybookForm() {
  const { trades } = useTrades();
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<GeneratePlaybookOutput | null>(null);
  const [error, setError] = useState<string | null>(null);

  const form = useForm<PlaybookFormValues>({
    resolver: zodResolver(playbookFormSchema),
    defaultValues: {
      strategy: '',
    },
  });

  async function onSubmit(data: PlaybookFormValues) {
    setIsLoading(true);
    setResult(null);
    setError(null);
    try {
      const pastData = JSON.stringify(trades.slice(0, 10), null, 2);
      const res = await generatePlaybook({ ...data, pastData });
      setResult(res);
    } catch (e) {
      setError('Failed to generate playbook. Please try again.');
      console.error(e);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
      <Card>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardHeader>
              <CardTitle>AI Playbook Generator</CardTitle>
              <CardDescription>
                Define a trading strategy or instrument, and our AI will generate a playbook based on your past trades.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <FormField
                control={form.control}
                name="strategy"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Strategy / Instrument</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 'Breakout strategy' or 'TSLA'" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </CardContent>
            <CardFooter>
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                ) : (
                  <Wand2 className="mr-2 h-4 w-4" />
                )}
                Generate Playbook
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
      
      <Card className="flex flex-col">
        <CardHeader>
          <CardTitle>Generated Playbook</CardTitle>
          <CardDescription>The AI-generated strategy analysis appears here.</CardDescription>
        </CardHeader>
        <CardContent className="flex-1 space-y-4">
          {isLoading && (
            <div className="flex items-center justify-center h-full">
              <Loader2 className="h-8 w-8 animate-spin text-muted-foreground" />
            </div>
          )}
          {error && <p className="text-destructive">{error}</p>}
          {result && (
            <div className="space-y-6">
              <div>
                <h3 className="font-semibold text-lg mb-2">AI Explanation</h3>
                <p className="text-muted-foreground whitespace-pre-wrap">{result.explanation}</p>
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-2">Trade Playbook</h3>
                <Textarea readOnly value={result.playbook} className="h-64 bg-muted" />
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
